--drop table operator
create table Operator
(
	OperatorId varchar(20) NOT NULL Primary Key,
	OperatorPassword varchar(50),
	FullName varchar(90),
	Email varchar(50),
	Phone varchar(15),
	WorkLocation varchar(50),
	Active bit default 1 
)
GO
--drop table customer
CREATE TABLE Customer
(
	CustomerId varchar(20) NOT NULL Primary Key,
	CustomerName Varchar(90),
	Address  Varchar(400),
	Email varchar(50),
	Phone varchar(15),
	Active bit default 1 
)
GO
CREATE TABLE Payment
(
	PaymentId INT IDENTITY(1,1) Primary Key,
	CustomerId varchar(20) NOT NULL,
	OperatorId varchar(20),
	OpeningDebt  float NOT NULL ,
	Currency Varchar(5),
	InvoiceNumber Varchar(20)
)
GO
-- DROP TABLE PaymentDetails
CREATE TABLE PaymentDetails
(
	PaymentId INT NOT NULL,
	RecNo SmallInt NOT NULL,
	PaymentTime DateTime NOT NULL,
	Description varchar(200),
	Amount float NOT NULL
)
ALTER TABLE PaymentDetails
    ADD CONSTRAINT pk_PaymentDetails PRIMARY KEY (PaymentId,RecNo)
GO
GO